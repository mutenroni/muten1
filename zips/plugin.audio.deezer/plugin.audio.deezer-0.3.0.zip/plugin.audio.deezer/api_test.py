# -*- coding: utf-8 -*-
from resources.lib.DeezerApi import Connection, Api


connection = Connection('famille.doreau@outlook.fr', 'p0uc3tt3.77')
api = Api(connection)
