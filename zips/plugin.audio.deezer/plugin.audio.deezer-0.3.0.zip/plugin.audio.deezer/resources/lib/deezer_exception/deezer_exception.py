"""
This module defines the base Exception class for DeezerKodi.
"""


class DeezerException(Exception):
    """Base class for every DeezerKodi errors"""

    CODE = 0
