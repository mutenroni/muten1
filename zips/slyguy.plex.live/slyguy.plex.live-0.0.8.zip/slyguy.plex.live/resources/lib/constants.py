DATA_URL = 'https://i.mjh.nz/Plex/app.json.gz'
EPG_URL = 'https://i.mjh.nz/Plex/all.xml.gz'
PLAY_URL = 'https://epg.provider.plex.tv/library/parts/{id}'
ALL = '_'
