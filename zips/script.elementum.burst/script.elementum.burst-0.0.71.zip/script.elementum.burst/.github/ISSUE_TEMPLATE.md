<!--- 
      DEVELOPMENT OF script.elementum.burst is stopped! 
      YOU WILL NOT GET SUPPORT or HELP!
      
      Feel free to fork the project!
-->
