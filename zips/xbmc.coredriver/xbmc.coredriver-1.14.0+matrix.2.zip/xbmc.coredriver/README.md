script.module.coredriver
==================

Python idna library packed for KODI.

See https://github.com/kjd/coredriver
